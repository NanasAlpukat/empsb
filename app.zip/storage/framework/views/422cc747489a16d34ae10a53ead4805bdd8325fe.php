<h4><?php echo e($email['title']); ?></h4>
<body>
    <?php echo e($email['body']); ?>

    <h4>Rincian</h4>
        <div style="margin-top: -8px;">
            <p style="font-size:10px;">Nama : <?php echo e($email['name']); ?></p>
            <p style="font-size:10px;">Jurusan : <?php echo e($email['major_name']); ?></p>
            <p style="font-size:10px;">Tagihan : <?php echo e($email['bill_name']); ?></p>
            <p style="font-size:10px;">Status : <?php echo e($email['status']); ?></p> 
            <p style="font-size:10px;">Total biaya : Rp.<?php echo e($email['price']); ?></p>  
        </div>
    <p>Silakan klik tombol Process</p>
   
    
</body><?php /**PATH B:\proyek perancangan program\emps\laravel-8\example-app\resources\views/view/email.blade.php ENDPATH**/ ?>